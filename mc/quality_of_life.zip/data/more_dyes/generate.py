#Created by AntisocialWeeb.
#  twitter.com/AntisocialWeeb
#  reddit.com/user/AntisocialWeeb
#  ryan#4755

import os
import codecs

directory = os.getcwd().rsplit("/",1)[1]
print(directory)

for file in os.listdir("recipes"):
    if file.startswith("."): continue
#    print(file)
#    json = eval(open("recipes/"+file, "r", encoding="utf8").read())
    json = eval(codecs.open("recipes/"+file,'r', encoding='ascii', errors='ignore').read())
#    print(json)
    result = json["result"]["item"] if type(json["result"]) == dict else json["result"]
    newjson = {
  "parent": directory+":recipes/root",
  "rewards": {
    "recipes": [
      directory+":"+file.replace(".json","",1)
    ]
  },
  "criteria": {
    "has_the_recipe": {
      "trigger": "minecraft:recipe_unlocked",
      "conditions": {
        "recipe": directory+":"+file.replace(".json","",1)
      }
    }
  },
  "requirements": [
    [
      "has_the_recipe"
    ]
  ]
}

    itemlist = []
    if json["type"].endswith("crafting_shaped"):
        for value in json["key"].values():
            if "tag" in value: itemtype = "tag"
            else: itemtype = "item"
            itemlist.append([itemtype, value[itemtype]])
    elif json["type"].endswith("crafting_shapeless"):
        for value in json["ingredients"]:
            if "tag" in value: itemtype = "tag"
            else: itemtype = "item"
            itemlist.append([itemtype, value[itemtype]])
    elif json["type"].endswith(("smelting","campfire_cooking","smoking","blasting","stonecutting")):
        if "tag" in json["ingredient"]: itemtype = "tag"
        else: itemtype = "item"
        itemlist.append([itemtype, json["ingredient"][itemtype]])

    if len(itemlist) == 0:
        continue

    for item in itemlist:
        newitem = item[1].replace("minecraft:","",1)
        newjson["criteria"]["has_"+newitem] = {
          "trigger": "minecraft:inventory_changed",
          "conditions": {
            "items": [
              {
                item[0]: item[1]
              }
            ]
          }
        }

        newjson["requirements"][0].append("has_"+newitem)

        newjson["requirements"].append(["has_"+newitem])

    savefile = open("advancements/recipes/"+file, "w", encoding="utf8")
    savefile.write(str(newjson).replace("'","\""))
    savefile.close()

print("Done!")
