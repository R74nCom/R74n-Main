while True:
    item = input("First Item: ").lower()
    addition = input("Addition: ").lower()
    result = input("Result: ").lower()
    json = """{
"type": "minecraft:smithing",
"base": {
    "item": "minecraft:"""+item+""""
},
"addition": {
    "item": "minecraft:"""+addition+""""
},
"result": {
    "item": "minecraft:"""+result+""""
}
}"""
    savefile = open(result+"_from_"+item+"_"+addition+".json","w",encoding="utf8")
    savefile.write(json)
    savefile.close()
