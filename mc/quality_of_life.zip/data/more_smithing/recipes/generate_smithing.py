while True:
    tier1 = input("First Tier: ").lower()
    tier2 = input("Result Tier: ").lower()
    item = input("Addition: ").lower()
    for itemtype in ["sword","pickaxe","axe","shovel","hoe","helmet","chestplate","leggings","boots"]:
        json = """{
  "type": "minecraft:smithing",
  "base": {
    "item": "minecraft:"""+tier1+"""_"""+itemtype+""""
  },
  "addition": {
    "item": "minecraft:"""+item+""""
  },
  "result": {
    "item": "minecraft:"""+tier2+"""_"""+itemtype+""""
  }
}"""
        savefile = open(tier1+"_to_"+tier2+"_"+itemtype+".json","w",encoding="utf8")
        savefile.write(json)
        savefile.close()
