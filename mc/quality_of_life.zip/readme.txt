Welcome to the Quality of Life Datapack!



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
To enable, put the compressed ZIP file that this file was in named "quality_of_life.zip" into the "datapacks" folder in your world save.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



Inside the folder named "data" are different folders that serve different purposes.

You can delete the ones that you don't want.

/!\ "more_tags" - DO NOT DELETE THIS. This adds many technical tags that are used throughout the whole datapack. Everything will break if you remove this one :) /!\

"customrecipes" - Adds many crafting recipes that you will appreciate. These are automatically unlocked in the recipe book when you obtain the ingredients needed to make them.

"universal_crafting" - Allows crafting using alternative ingredients, such as andesite/granite/diorite for cobblestone, bamboo for sticks, dyeing already dyed items, diagonal recipes and much more.

/!\ "creative_crafting" - Adds recipes to craft creative/command-only items. Might wanna disable this if you don't like the sound of that. (Anything dangerous can't be used in survival though anyway.) /!\

"more_smelting" - Adds smelting recipes that allow for breaking down of other iron and gold items and the smelting of slabs and stairs. Also adds extra blast furnace, smoker, and campfire support. Blasting most organic things like plants and food will produce charcoal.

"more_stonecutting" - Adds A LOT of stonecutter recipes. This includes wooden things, polishing stairs and slabs, cutting stairs, cutting leaves and so much more.

"more_dyes" - Craft dyes in more ways, like white dye from white tulips and oxeye daisies, dyes from coral, 3 carrots, 3 potatoes, mushrooms, honeycombs, redstone, charcoal, chorus fruit (including popped), and grinding meat in a stonecutter.

"more_smithing" - Upgrade more than just diamond gear in the smithing table, plus a few normal 2-item recipes. Upgrading to diamond costs a whole block so it is balanced.

"desert_survival" - Adds recipes to survive in an all-desert world.

"give" - Adds functions that give you cool stuff. /function give:X

"heads": - Adds functions that give you custom player heads. /function heads:X

"s" - Adds preset copypastas and other things in the form of functions. /function s:X

"minecraft": - Adds minor gameplay improvements like...
- Farmland, path blocks, and chorus plants can be silk touched
- Some blocks will save their states when silk touched, like lamps, bells, furnaces, cake, cauldrons, redstone, campfires, composters, and repeaters
- Empty knowledge books can be found in stronghold libraries
- Librarians can give you empty knowledge books or written books after defeating a raid
- Bamboo can be placed on more blocks for aesthetics
- Shears mine carpets and banners faster
- Climbable end rods, chains, and iron bars
- Beacons can be given any items made of gold, iron, diamonds, or netherite
- Beacons can be made out of more beacons
- Hoglins are repelled by warped wart blocks
- Faster walking through soul fire with Soul Speed
- Piglins will guard light weighted pressure plates
- Striders will be warm on torches and campfires
- Campfires, torches, lanterns, and smithing tables can be used as fuel
- Fire charges and blaze powder can be used in place of coal